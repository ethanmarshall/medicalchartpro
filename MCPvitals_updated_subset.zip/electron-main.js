import { app, BrowserWindow, ipcMain, shell, dialog } from 'electron';
import path from 'path';
import { spawn } from 'child_process';
import ActivationSystem from './server/activation-system.js';

let mainWindow;
let serverProcess;
let activationSystem;
let splashWindow;

function createSplashWindow() {
  splashWindow = new BrowserWindow({
    width: 400,
    height: 300,
    frame: false,
    alwaysOnTop: true,
    transparent: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  // Create splash content
  splashWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          margin: 0;
          padding: 0;
          background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
          color: white;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          border-radius: 12px;
        }
        .content {
          text-align: center;
        }
        .logo {
          font-size: 48px;
          margin-bottom: 16px;
        }
        .title {
          font-size: 24px;
          font-weight: bold;
          margin-bottom: 8px;
        }
        .subtitle {
          font-size: 14px;
          opacity: 0.8;
          margin-bottom: 24px;
        }
        .spinner {
          width: 32px;
          height: 32px;
          border: 3px solid rgba(255,255,255,0.3);
          border-radius: 50%;
          border-top-color: white;
          animation: spin 1s ease-in-out infinite;
          margin: 0 auto;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      </style>
    </head>
    <body>
      <div class="content">
        <div class="logo">🏥</div>
        <div class="title">MedChart Pro</div>
        <div class="subtitle">Medical Training Platform</div>
        <div class="spinner"></div>
      </div>
    </body>
    </html>
  `)}`);

  splashWindow.on('closed', () => {
    splashWindow = null;
  });
}

function createWindow() {
  // Create the browser window
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 1000,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      webSecurity: true,
      preload: path.join(__dirname, 'electron-preload.js')
    },
    icon: path.join(__dirname, 'assets/icon.png'), // You can add an icon file later
    title: 'MedChart Pro',
    show: false
  });

  // Start the Express server
  startServer();

  // Load the app
  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    // In development, connect to the dev server
    mainWindow.loadURL('http://localhost:5000');
    // Open DevTools in development
    mainWindow.webContents.openDevTools();
  } else {
    // In production, the server serves the built client
    mainWindow.loadURL('http://localhost:5000');
  }

  // Show window when ready and check activation
  mainWindow.once('ready-to-show', async () => {
    // Close splash window
    if (splashWindow) {
      splashWindow.close();
    }
    
    // Check activation status
    const isActivated = activationSystem.isActivated();
    const trialInfo = await getTrialInfo();
    
    if (!isActivated && (!trialInfo || trialInfo.expired)) {
      // Show activation required dialog
      mainWindow.webContents.send('activation-required');
    }
    
    mainWindow.show();
  });

  // Handle window closed
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function startServer() {
  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    // In development, start the dev server
    serverProcess = spawn('npm', ['run', 'dev'], {
      stdio: 'inherit',
      shell: true
    });
  } else {
    // In production, start the built server
    serverProcess = spawn('node', ['dist/index.js'], {
      stdio: 'inherit',
      env: { ...process.env, NODE_ENV: 'production' }
    });
  }
}

// Initialize activation system and IPC handlers
function initializeActivationSystem() {
  activationSystem = new ActivationSystem();
  
  // IPC Handlers for activation
  ipcMain.handle('check-activation-status', async () => {
    return {
      isActivated: activationSystem.isActivated(),
      activationInfo: activationSystem.getActivationInfo(),
      trialInfo: await getTrialInfo()
    };
  });
  
  ipcMain.handle('activate-license', async (event, licenseKey) => {
    try {
      await activationSystem.activate(licenseKey);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  });
  
  ipcMain.handle('get-activation-info', () => {
    return activationSystem.getActivationInfo();
  });
  
  ipcMain.handle('deactivate-license', () => {
    activationSystem.deactivate();
    return { success: true };
  });
  
  // Trial system handlers
  ipcMain.handle('get-trial-info', async () => {
    return await getTrialInfo();
  });
  
  ipcMain.handle('start-trial', async () => {
    return await startTrial();
  });
  
  // App info handlers
  ipcMain.handle('get-app-version', () => {
    return app.getVersion();
  });
  
  // Utility handlers
  ipcMain.handle('open-external', (event, url) => {
    shell.openExternal(url);
  });
  
  ipcMain.handle('minimize-window', () => {
    if (mainWindow) mainWindow.minimize();
  });
  
  ipcMain.handle('maximize-window', () => {
    if (mainWindow) {
      if (mainWindow.isMaximized()) {
        mainWindow.unmaximize();
      } else {
        mainWindow.maximize();
      }
    }
  });
  
  ipcMain.handle('close-window', () => {
    if (mainWindow) mainWindow.close();
  });
  
  ipcMain.handle('open-dev-tools', () => {
    if (mainWindow && process.env.NODE_ENV === 'development') {
      mainWindow.webContents.openDevTools();
    }
  });
}

// Trial system functions
async function getTrialInfo() {
  const trialFile = path.join(app.getPath('userData'), 'trial.json');
  
  try {
    if (await import('fs').then(fs => fs.existsSync(trialFile))) {
      const fs = await import('fs');
      const trialData = JSON.parse(fs.readFileSync(trialFile, 'utf8'));
      const startDate = new Date(trialData.startDate);
      const expiryDate = new Date(startDate.getTime() + (7 * 24 * 60 * 60 * 1000)); // 7 days
      const now = new Date();
      const daysRemaining = Math.max(0, Math.ceil((expiryDate.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)));
      
      return {
        isTrialActive: true,
        startDate: trialData.startDate,
        expiryDate: expiryDate.toISOString(),
        daysRemaining,
        expired: daysRemaining <= 0
      };
    }
  } catch (error) {
    console.error('Error reading trial info:', error);
  }
  
  return null;
}

async function startTrial() {
  const trialFile = path.join(app.getPath('userData'), 'trial.json');
  const trialData = {
    startDate: new Date().toISOString()
  };
  
  try {
    const fs = await import('fs');
    fs.writeFileSync(trialFile, JSON.stringify(trialData));
    return { success: true, trialInfo: await getTrialInfo() };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// App event handlers
app.whenReady().then(() => {
  initializeActivationSystem();
  createSplashWindow();
  
  // Create main window after a short delay
  setTimeout(() => {
    createWindow();
  }, 2000);
});

app.on('window-all-closed', () => {
  // Kill the server process when closing
  if (serverProcess) {
    serverProcess.kill();
  }
  
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Handle app termination
app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});