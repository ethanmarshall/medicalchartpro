MCPvitals – Updated Files (subset)

These are the files that were updated in the integration/security pass.
Copy each file into the matching path in your repository root. For example:
- client/src/components/enhanced-vitals.tsx  -> <repo>/client/src/components/enhanced-vitals.tsx
- client/src/components/vitals.tsx           -> <repo>/client/src/components/vitals.tsx
- client/src/index.css                       -> <repo>/client/src/index.css
- tailwind.config.ts                         -> <repo>/tailwind.config.ts
- vite.config.ts                             -> <repo>/vite.config.ts
- electron-preload.js                        -> <repo>/electron-preload.js
- electron-main.js                           -> <repo>/electron-main.js
- package.json                               -> <repo>/package.json
- postcss.config.js                          -> <repo>/postcss.config.js
- tsconfig.json                              -> <repo>/tsconfig.json

After copying:
1) npm install
2) npm run build   (or npm run dev for local)
3) If using Electron: verify BrowserWindow security flags and preload exposure.