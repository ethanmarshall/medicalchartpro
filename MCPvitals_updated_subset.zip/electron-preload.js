const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // Activation system
  checkActivationStatus: () => ipcRenderer.invoke('check-activation-status'),
  activateLicense: (licenseKey) => ipcRenderer.invoke('activate-license', licenseKey),
  getActivationInfo: () => ipcRenderer.invoke('get-activation-info'),
  deactivateLicense: () => ipcRenderer.invoke('deactivate-license'),
  
  // Trial system
  getTrialInfo: () => ipcRenderer.invoke('get-trial-info'),
  startTrial: () => ipcRenderer.invoke('start-trial'),
  
  // App info
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  // External links
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  
  // Window controls
  minimizeWindow: () => ipcRenderer.invoke('minimize-window'),
  maximizeWindow: () => ipcRenderer.invoke('maximize-window'),
  closeWindow: () => ipcRenderer.invoke('close-window'),
  
  // App events
  onActivationRequired: (callback) => {
    ipcRenderer.on('activation-required', callback);
  },
  
  removeAllListeners: (channel) => {
    ipcRenderer.removeAllListeners(channel);
  },
  
  // Development tools (only in development)
  isDev: () => process.env.NODE_ENV === 'development',
  openDevTools: () => {
    if (process.env.NODE_ENV === 'development') {
      ipcRenderer.invoke('open-dev-tools');
    }
  }
});

// Prevent new window creation (security)
window.addEventListener('DOMContentLoaded', () => {
  const replaceText = (selector, text) => {
    const element = document.getElementById(selector);
    if (element) element.innerText = text;
  };

  for (const dependency of ['chrome', 'node', 'electron']) {
    replaceText(`${dependency}-version`, process.versions[dependency]);
  }
});